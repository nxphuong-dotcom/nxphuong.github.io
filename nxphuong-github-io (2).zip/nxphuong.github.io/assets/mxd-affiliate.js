console.log('mxd-affiliate.js (stub) — rewrite affiliate links here');
