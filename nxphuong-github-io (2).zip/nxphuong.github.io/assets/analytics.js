console.log('analytics.js loaded (GA4 placeholder)');
