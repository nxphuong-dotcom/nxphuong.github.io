# nxphuong.github.io — Starter
Bước:
1) Tạo repo **nxphuong.github.io** (Public).
2) Upload toàn bộ lên nhánh `main` (Add file → Upload files).
3) Settings → Pages: Deploy from a branch → `main` / `/` → Save.
4) Mở https://nxphuong.github.io

Chuẩn MXD:
- GA4 `/assets/analytics.js` **trước** `/assets/mxd-affiliate.js`.
- Ảnh sản phẩm: `/assets/img/products/<sku>.webp`.
- Sửa `affiliates.json`, mở `/g.html?sku=<sku>` để xem.
